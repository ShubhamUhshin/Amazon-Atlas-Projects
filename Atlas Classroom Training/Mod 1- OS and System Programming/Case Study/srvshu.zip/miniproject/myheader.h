//This file contains the list of all header files used in this project.

#include<stdio.h>
#include<fcntl.h>
#include<string.h>
#include<sys/wait.h>
#include<unistd.h>
#include<stdlib.h>
#include<ctype.h>
