#command line argument

echo "argument 0 = $0"
echo "argument 1 = $1"
echo "argument 2 = $2"
echo "argument 3 = $3"
echo "argument 4 = $4"
echo "argument 5 = $5"
echo "argument 6 = $6"
echo "argument 7 = $7"
echo "argument 8 = $8"
echo "argument 9 = $9"
echo "Number of arguments = $#"

