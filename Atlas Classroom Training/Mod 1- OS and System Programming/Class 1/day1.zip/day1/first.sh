ls
date
whoami
ls -a
pwd
date +%d-%m-%Y
