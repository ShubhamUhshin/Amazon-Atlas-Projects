var1=10;var2=20
var3=30;
var4=40;
echo "Hello and welcome to shell programming var1 = $var1"
<<com
echo "shell programs follow interpreter structure var2 = $var2"
echo "shell only excutes commands var3 = $var3"
echo "everythin is a character or string in shell var4 = $var4"
com
echo "end"
echo "bye"
