echo "Enter Number1 :: " #printf print
read num1                #scanf  input 
echo "Enter Number2 :: "
read num2

echo "Num1 = $num1"
echo "Num2 = $num2"
