#!/bin/bash
echo  "demo for loop"
for var in 11 22 33 44 55 66 77 88 99 45 32 12 65
do
	echo "in for loop"
	echo "var = $var "
	echo "loooping......."

done

echo "bye"
echo "end"
