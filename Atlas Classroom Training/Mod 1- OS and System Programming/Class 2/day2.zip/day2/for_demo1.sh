#!/bin/bash
echo  "demo for loop"
for var in {1..20..3}
do
	echo "in for loop"
	echo "var = $var "
	echo "loooping......."

done

echo "bye"
echo "end"
