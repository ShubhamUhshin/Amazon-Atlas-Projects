#!/bin/bash
echo  "demo for loop"
for (( i=0 ; i < 10 ; i++ ))
do
	echo "in for loop"
	echo "i = $i"

done

echo "bye"
echo "end"
