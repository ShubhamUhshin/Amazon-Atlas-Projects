#!/bin/bash

sayHello()
{
	echo "say hello functions"
	echo "say Hello functions running"
	echo "end of sayhello functions"
}

echo "in main script"
sayHello
echo "end"
echo "Bye"

