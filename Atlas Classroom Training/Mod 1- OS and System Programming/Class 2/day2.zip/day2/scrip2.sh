echo "in script2.sh"
echo "script2.sh started"
echo "in scrip2 myvar = $myvar"
echo "script2.sh running"
sleep 2
echo "script2.sh running"
echo "in scrip2 myvar = $myvar"
sleep 2
echo "script2.sh running"
echo "in scrip2 myvar = $myvar"
sleep 2
echo "script2.sh running"
echo "in scrip2 myvar = $myvar"
sleep 2
echo "script2.sh running"
echo "in scrip2 myvar = $myvar"
sleep 2
echo "script2.sh running"
echo "in scrip2 myvar = $myvar"
sleep 2
echo "end of script2.sh"


