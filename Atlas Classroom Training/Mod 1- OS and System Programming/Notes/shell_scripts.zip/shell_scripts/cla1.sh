#command line argument
res=`expr $1 + $2`
echo $res

