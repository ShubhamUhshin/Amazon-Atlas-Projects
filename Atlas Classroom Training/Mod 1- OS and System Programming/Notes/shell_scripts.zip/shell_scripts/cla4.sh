echo "Calculator appliaction"
echo $@
