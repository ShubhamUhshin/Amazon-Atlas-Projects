package com.amazon.atlas22.casestudy;

public class MLMCaseStudyApp {

	public static void main(String[] args) {
		

	}

}
