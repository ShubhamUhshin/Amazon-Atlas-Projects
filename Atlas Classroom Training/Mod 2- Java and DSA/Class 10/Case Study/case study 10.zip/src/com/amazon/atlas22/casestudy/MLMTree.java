package com.amazon.atlas22.casestudy;

public class MLMTree {

	String organization;
	int numberOfDistributors;
	
	public MLMTree() {
		this("NA");
	}

	public MLMTree(String organization) {
		this.organization = organization;
		numberOfDistributors = 0;
	}
	
	void insertRootDistributor(Distributor distributor) {
		
	}
	
	void sponsorNewDistributor(Distributor distributor, Distributor newDistributor) {
		
	}
	
	void iterateTreeOfUser(Distributor distributor) {
		
	}
	
}
