package com.amazon.atlas22.main;

import com.amazon.atlas22.datastructures.AVLTree;
import com.amazon.atlas22.model.Node;

public class AVLTreeApp {

	public static void main(String[] args) {
		
		AVLTree tree = new AVLTree();
		Node rootNode = tree.insert(null, 20);
		tree.insert(rootNode, 30);
	}

}
