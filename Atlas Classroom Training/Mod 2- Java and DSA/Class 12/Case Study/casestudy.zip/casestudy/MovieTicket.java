package com.amazon.atlas22.casestudy;

public class MovieTicket {
	
	String name;
	String time;
	int price;
	int seatNumber;
	char rowNumber;
	String userEmail;
	
	public MovieTicket() {
		
	}
	
	public MovieTicket(String name, String time, int price, int seatNumber, char rowNumber) {
		this.name = name;
		this.time = time;
		this.price = price;
		this.seatNumber = seatNumber;
		this.rowNumber = rowNumber;
	}
	
	public void payForTicket(int amount, User user) {
		System.out.println("Paying for Movie: "+name);
		System.out.println("Thank you "+user.name+" to make a payment..");
		userEmail = user.email;
		System.out.println("Ticket Booked and Email Sent....");
	}

	@Override
	public String toString() {
		return "MovieTicket [name=" + name + ", time=" + time + ", price=" + price + ", seatNumber=" + seatNumber
				+ ", rowNumber=" + rowNumber + ", userEmail=" + userEmail + "]";
	}

}
