package com.amazon.atlas22.graphalgos;

public class Vertex {

	int number;
	
	public Vertex(int number){
		this.number = number;
	}

	@Override
	public String toString() {
		return "Vertex [number=" + number + "]";
	}
	
}
