package com.amazon.atlas22.fileio;

public class JavaClassDemo{
	public static void main(String[] args) {
		System.out.println("Hello World..");
	}
}