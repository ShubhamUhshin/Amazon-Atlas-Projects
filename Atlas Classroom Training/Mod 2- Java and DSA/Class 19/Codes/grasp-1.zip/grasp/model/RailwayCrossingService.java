package com.amazon.atlas22.grasp.model;

import java.util.ArrayList;
import java.util.List;

// Responsibility to manage RailwayCrossing or to interact with DB :)
public class RailwayCrossingService {
	
	static RailwayCrossingService service = new RailwayCrossingService();
	
	static RailwayCrossingService getInstance() {
		return service;
	}
	
	// Temporary Data Structure
	// In real world Service is the One, which will interact with DataBase
	List<RailwayCrossing> crossings;
	
	private RailwayCrossingService(){
		crossings = new ArrayList<RailwayCrossing>();	
	}
	
	
	public String addRailwayCrossing(RailwayCrossing crossing) {
		crossings.add(crossing);
		return "Crossing "+crossing.name+" Added :)";
	}
}
