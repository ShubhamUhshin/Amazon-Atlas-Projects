package com.amazon.atlas22.grasp.model;

public class User {

}
