package com.amazon.atlas22.main;

import com.amazon.atlas22.datastructures.BinarySearchTree;
import com.amazon.atlas22.model.Node;

public class TreeApp {

	public static void main(String[] args) {
		
		BinarySearchTree tree = new BinarySearchTree();
		Node rootNode = tree.insert(null, 15);
		tree.insert(rootNode, 20);
		tree.insert(rootNode, 10);
		
		
		System.out.println();
		System.out.println("Tree Size is: "+tree.getSize());
		System.out.println("Root Node in Tree is: "+tree.getRootNode());
		tree.getRootNode().showNode();

	}

}
