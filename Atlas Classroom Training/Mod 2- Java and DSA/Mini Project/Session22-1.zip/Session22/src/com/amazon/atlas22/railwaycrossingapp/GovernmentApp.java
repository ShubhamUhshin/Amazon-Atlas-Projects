package com.amazon.atlas22.railwaycrossingapp;

public class GovernmentApp {

	public static void main(String[] args) {
		

	}

}
