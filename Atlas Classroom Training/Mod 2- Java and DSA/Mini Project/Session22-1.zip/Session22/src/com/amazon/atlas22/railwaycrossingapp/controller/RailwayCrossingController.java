package com.amazon.atlas22.railwaycrossingapp.controller;

public class RailwayCrossingController {

}
