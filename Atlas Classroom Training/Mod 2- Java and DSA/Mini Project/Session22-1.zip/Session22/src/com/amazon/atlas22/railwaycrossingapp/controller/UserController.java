package com.amazon.atlas22.railwaycrossingapp.controller;

import com.amazon.atlas22.railwaycrossingapp.db.DB;
import com.amazon.atlas22.railwaycrossingapp.model.User;

public class UserController {

	DB db = DB.getInstance();
	
	public boolean registerUser(User user) {
		
		if(user.validate())
			return db.set(user);
		else
			System.err.println("Email and Password should be non empty");
		
		return false;
	}
	
}
