package com.amazon.atlas22.railwaycrossingapp;

public class PublicApp {

	public static void main(String[] args) {
		

	}

}
