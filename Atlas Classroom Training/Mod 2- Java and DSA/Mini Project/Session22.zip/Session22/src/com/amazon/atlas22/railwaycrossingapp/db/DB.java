package com.amazon.atlas22.railwaycrossingapp.db;

import java.util.LinkedHashMap;

public class DB {

	//LinkedHashMap<K, V>
	
}
