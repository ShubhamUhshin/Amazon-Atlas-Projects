package com.amazon.atlas22.railwaycrossingapp.model;

public class RailwayCrossing {

}
