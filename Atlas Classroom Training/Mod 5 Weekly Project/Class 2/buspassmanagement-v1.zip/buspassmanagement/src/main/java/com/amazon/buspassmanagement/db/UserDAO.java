package com.amazon.buspassmanagement.db;

import java.util.List;

import com.amazon.buspassmanagement.model.User;

public class UserDAO implements DAO<User>{

	DB db = DB.getInstance();
	
	@Override
	public int insert(User object) {
		String sql = "INSERT INTO User (name, phone, email, password, address, department, type) VALUES ('"+object.name+"', '"+object.phone+"', '"+object.email+"', '"+object.password+"', '"+object.address+"', '"+object.department+"', "+object.type+")";
		return db.executeSQL(sql);
	}

	@Override
	public int update(User object) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(User object) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<User> retrieve() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
