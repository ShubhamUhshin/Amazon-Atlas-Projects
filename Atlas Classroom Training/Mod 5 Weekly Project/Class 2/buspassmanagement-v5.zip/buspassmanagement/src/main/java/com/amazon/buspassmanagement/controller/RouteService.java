package com.amazon.buspassmanagement.controller;

import com.amazon.buspassmanagement.db.RouteDAO;
import com.amazon.buspassmanagement.db.StopDAO;
import com.amazon.buspassmanagement.db.VehicleDAO;

// To handle Route, Stop and Vehicles :)
public class RouteService {

	RouteDAO routeDAO = new RouteDAO();
	StopDAO stopDAO = new StopDAO();
	VehicleDAO vehicleDAO = new VehicleDAO();
	
	// Create it as a Singleton 
	private static RouteService routeService = new RouteService();
	
	public static RouteService getInstance() {
		return routeService;
	}
	
	private RouteService() {
	
	}
	
}
