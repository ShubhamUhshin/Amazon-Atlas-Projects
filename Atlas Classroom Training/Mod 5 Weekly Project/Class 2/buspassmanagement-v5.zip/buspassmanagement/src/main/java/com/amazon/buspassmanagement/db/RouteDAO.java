package com.amazon.buspassmanagement.db;

import java.util.List;

import com.amazon.buspassmanagement.model.Route;

public class RouteDAO implements DAO<Route> {

	@Override
	public int insert(Route object) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Route object) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(Route object) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Route> retrieve() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Route> retrieve(String sql) {
		// TODO Auto-generated method stub
		return null;
	}

}
