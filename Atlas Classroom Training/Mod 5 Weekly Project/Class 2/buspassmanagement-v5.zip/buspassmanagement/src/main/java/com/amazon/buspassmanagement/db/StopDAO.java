package com.amazon.buspassmanagement.db;

import java.util.List;

import com.amazon.buspassmanagement.model.Stop;

public class StopDAO implements DAO<Stop>{

	@Override
	public int insert(Stop object) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Stop object) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(Stop object) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Stop> retrieve() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Stop> retrieve(String sql) {
		// TODO Auto-generated method stub
		return null;
	}

}
