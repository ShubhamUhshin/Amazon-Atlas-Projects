package com.amazon.buspassmanagement.db;

import java.util.List;

import com.amazon.buspassmanagement.model.Vehicle;

public class VehicleDAO implements DAO<Vehicle> {

	@Override
	public int insert(Vehicle object) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Vehicle object) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(Vehicle object) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Vehicle> retrieve() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Vehicle> retrieve(String sql) {
		// TODO Auto-generated method stub
		return null;
	}

}
