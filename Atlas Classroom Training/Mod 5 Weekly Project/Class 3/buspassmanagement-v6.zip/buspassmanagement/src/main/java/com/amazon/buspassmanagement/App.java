package com.amazon.buspassmanagement;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Date;
import java.util.Scanner;

import com.amazon.buspassmanagement.controller.AuthenticationService;
import com.amazon.buspassmanagement.controller.RouteService;
import com.amazon.buspassmanagement.db.DB;
import com.amazon.buspassmanagement.db.UserDAO;
import com.amazon.buspassmanagement.model.User;

public class App {
	
	AuthenticationService auth = AuthenticationService.getInstance(); 
	RouteService routeService = RouteService.getInstance();
	
	private App() {
    	System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println( "Welcome to Bus Pass Management Application" );
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}
	
	Scanner scanner = new Scanner(System.in);
	
	void showMainMenu() {
		// Initial Menu for the Application
        while(true) {
        	
        	System.out.println("1: Admin");
        	System.out.println("2: User");
        	System.out.println("3: Quit");
        	System.out.println("Select an Option");
        	
        	int choice = scanner.nextInt();
        	
        	if(choice == 1) {
        		System.out.println("Navigating to Admin Menu...");
        		showAdminMenu();
        	}else if (choice == 2) {
        		System.out.println("Navigating to User Menu...");
        		showUserMenu();
        	}else if (choice == 3) {
        		System.out.println("Thank You For using Bus Pass Management App");
        		
        		// Close the DataBase Connection, when user has exited the application :)
        		DB db = DB.getInstance();
        		db.closeConnection();
        		break;
        	}	
        	else {
        		System.err.println("Invalid Choice...");
        	}
        	
        }
	}
	
	void showAdminMenu() {
		
		// Login Code should come before the Menu becomes Visible to the Admin
		User adminUser = new User();
		
		// An empty scanner.nextLine as we are reading string after int :)
		scanner.nextLine();
		
		System.out.println("Enter Your Email:");
		adminUser.email = scanner.nextLine();
		
		System.out.println("Enter Your Password:");
		adminUser.password = scanner.nextLine();
		
		boolean result = auth.loginUser(adminUser);
		
		if(result && adminUser.type == 1) {
			
			// Link the Admin User to the Session User :)
			BusPassSession.user = adminUser;
		
			System.out.println("*********************");
			System.out.println("Welcome to Admin App");
			System.out.println("Hello, "+adminUser.name);
			System.out.println("Its: "+new Date());
			System.out.println("*********************");
			
			boolean quit = false;
			
			while(true) {
	        	System.out.println("1: Manage Routes"); // here we mean -> add, update, delete and view :)
	        	System.out.println("2: Manage Stops");
	        	System.out.println("3: Manage Vehicles");
	        	System.out.println("4: Manage Bus Pass");
	        	System.out.println("5: Manage Feedbacks");
	        	System.out.println("6: Quit Admin App");
	        	System.out.println("Select an Option");
	        	
	        	int choice = scanner.nextInt();
	        	
	        	switch (choice) {
					case 1:
						
						System.out.println("1: Add Route");
						System.out.println("2: Update Route");
						System.out.println("3: Delete Route");
						System.out.println("4: View Routes");
						
						System.out.println("Enter Your Choice: ");
						int routeChoice = scanner.nextInt();
						
						if(routeChoice == 1) {
							routeService.addRoute();
						}else if(routeChoice == 2) {
							routeService.updateRoute();
						}else if (routeChoice == 3) {
							routeService.deleteRoute();
						}else if(routeChoice == 4) {
							routeService.viewRoutes();
						}else {
							System.err.println("Invalid Route Choice..");
						}
						
						break;
						
					case 2:
						
						break;
	
					case 3:
						
						break;
						
					case 4:
						
						break;
						
					case 5:
						
						break;
						
					case 6:
						System.out.println("Thank You for Using Admin App !!");
						quit = true;
						break;
		
					default:
						System.err.println("Invalid Choice...");
						break;
				}
	        	
	        	if(quit) {
	        		break;
	        	}
	        	
	        }
		}else {
			System.err.println("Invalid Credentials. Please Try Again !!");
		}
	}
	
	void showUserMenu() {
		
		System.out.println("1: Register");
		System.out.println("2: Login");
		System.out.println("3: Cancel");
		
		System.out.println("Enter Your Choice: ");
		int initialChoice = scanner.nextInt();
		
		boolean result = false;
		
		User user = new User();
		
		// An empty scanner.nextLine as we are reading string after int :)
		scanner.nextLine();
		
		if(initialChoice == 1) {
			
			System.out.println("Enter Your Name:");
			user.name = scanner.nextLine();
			
			System.out.println("Enter Your Phone:");
			user.phone = scanner.nextLine();
			
			System.out.println("Enter Your Email:");
			user.email = scanner.nextLine();
			
			System.out.println("Enter Your Password:");
			user.password = scanner.nextLine();
			
			try {
				// Hash the Password of User :)
				MessageDigest digest = MessageDigest.getInstance("SHA-256");
				byte[] hash = digest.digest(user.password.getBytes(StandardCharsets.UTF_8));
				user.password = Base64.getEncoder().encodeToString(hash);
			}catch (Exception e) {
				System.err.println("Something Went Wrong: "+e);
			}
			
			System.out.println("Enter Your Address:");
			user.address = scanner.nextLine();
			
			System.out.println("Enter Your Department:");
			user.department = scanner.nextLine();
			
			// As we know, user is registering :)
			user.type = 2;
			
			result = auth.registerUser(user);
			
		}else if(initialChoice == 2) {
			
			System.out.println("Enter Your Email:");
			user.email = scanner.nextLine();
			
			System.out.println("Enter Your Password:");
			user.password = scanner.nextLine();
			
			try {
				// Encoded to Hash i.e. SHA-256 so as to match correctly
				MessageDigest digest = MessageDigest.getInstance("SHA-256");
				byte[] hash = digest.digest(user.password.getBytes(StandardCharsets.UTF_8));
				user.password = Base64.getEncoder().encodeToString(hash);
			}catch (Exception e) {
				System.err.println("Something Went Wrong: "+e);
			}
			
			result = auth.loginUser(user);
			
		}else if(initialChoice == 3) {
			System.out.println("Thank You for Using Bus Pass App");
		}else {
			System.err.println("Invalid Choice...");
			System.out.println("Thank You for Using Bus Pass App");
		}
		
		
		if(result && user.type == 2) {
		
			// Link the User to the Session User :)
			BusPassSession.user = user;
			
			System.out.println("^^^^^^^^^^^^^^^^^^^");
			System.out.println("Welcome to User App");
			System.out.println("Hello, "+user.name);
			System.out.println("Its: "+new Date());
			System.out.println("^^^^^^^^^^^^^^^^^^^");
			
			boolean quit = false;
			
			while(true) {
	        	
	        	System.out.println("1: View Routes");
	        	System.out.println("2: Apply For Bus Pass");
	        	System.out.println("3: My Bus Pass");
	        	System.out.println("4: Request Pass Update");
	        	System.out.println("5: Write Feedback");
	        	System.out.println("6: My Profile");
	        	System.out.println("7: Quit User App");
	        	System.out.println("Select an Option");
	        	
	        	int choice = scanner.nextInt();
	        	
	        	switch (choice) {
					case 1:
						routeService.viewRoutes();
						break;
						
					case 2:
						
						break;
	
					case 3:
						
						break;
						
					case 4:
						
						break;
						
					case 5:
						
						break;
						
					case 6:
						System.out.println("My Profile");
						user.prettyPrint();
						
						System.out.println("Do you wish to update Profile (1: update 0: cancel)");
						choice = scanner.nextInt();
						
						if(choice == 1) {
							
							scanner.nextLine();
							
							System.out.println("Enter Your Name:");
							String name = scanner.nextLine();
							if(!name.isEmpty()) {
								user.name = name;
							}
							
							System.out.println("Enter Your Phone:");
							String phone = scanner.nextLine();
							if(!phone.isEmpty()) {
								user.phone = phone;
							}
							
							System.out.println("Enter Your Password:");
							String password = scanner.nextLine();
							if(!password.isEmpty()) {
								user.password = password;
							}
							
							System.out.println("Enter Your Address:");
							String address = scanner.nextLine();
							if(!address.isEmpty()) {
								user.address = address;
							}
							
							System.out.println("Enter Your Department:");
							String department = scanner.nextLine();
							if(!department.isEmpty()) {
								user.department = department;
							}
							
							if(auth.updateUser(user)) {
								System.out.println("Profile Updated Successfully");
							}else {
								System.err.println("Profile Update Failed...");
							}
							
						}
						break;
	
					case 7:
						System.out.println("Thank You for Using User App !!");
						quit = true;
						break;
		
					default:
						System.err.println("Invalid Choice...");
						break;
				}
	        	
	        	if(quit) {
	        		break;
	        	}
	        	
	        }
		}else {
			System.err.println("Authentication Failed..");
		}
	}
	
	
    public static void main( String[] args ){
        App app = new App();
        app.showMainMenu();
    }
    
}
