package com.amazon.buspassmanagement.controller;

import java.util.List;
import java.util.Scanner;

import com.amazon.buspassmanagement.BusPassSession;
import com.amazon.buspassmanagement.db.RouteDAO;
import com.amazon.buspassmanagement.db.StopDAO;
import com.amazon.buspassmanagement.db.VehicleDAO;
import com.amazon.buspassmanagement.model.Route;

// To handle Route, Stop and Vehicles :)
public class RouteService {

	RouteDAO routeDAO = new RouteDAO();
	StopDAO stopDAO = new StopDAO();
	VehicleDAO vehicleDAO = new VehicleDAO();
	
	// Create it as a Singleton 
	private static RouteService routeService = new RouteService();
	Scanner scanner = new Scanner(System.in);
	
	public static RouteService getInstance() {
		return routeService;
	}
	
	private RouteService() {
	
	}
	
	// Handler for the Route :)
	public void addRoute() {
		Route route = new Route();
		route.getDetails(false);
		
		// Add the admin ID Implicitly.
		route.adminId = BusPassSession.user.id;
		
		int result = routeDAO.insert(route);
		String message = (result > 0) ? "Route Added Successfully" : "Adding Route Failed. Try Again.."; 
		System.out.println(message);
	}
	
	public void deleteRoute() {
		Route route = new Route();
		System.out.println("Enter Route ID to be deleted: ");
		route.id = scanner.nextInt();
		int result = routeDAO.delete(route);
		String message = (result > 0) ? "Route Deleted Successfully" : "Deleting Route Failed. Try Again.."; 
		System.out.println(message);
	}
	
	public void updateRoute() {
		Route route = new Route();
		route.getDetails(true);
		
		// Add the admin ID Implicitly.
		route.adminId = BusPassSession.user.id;
		
		int result = routeDAO.update(route);
		String message = (result > 0) ? "Route Updated Successfully" : "Updating Route Failed. Try Again.."; 
		System.out.println(message);
	}
	
	public void viewRoutes() {
		List<Route> objects = routeDAO.retrieve();
		for(Route object : objects) {
			object.prettyPrint();
		}
	}
	
}
