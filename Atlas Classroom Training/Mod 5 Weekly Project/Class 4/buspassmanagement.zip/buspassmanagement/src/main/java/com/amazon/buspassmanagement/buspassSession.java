package com.amazon.buspassmanagement;

import com.amazon.buspassmanagement.model.User;

public class buspassSession {

	// Can hold the reference of a User Object :)
		public static User user = null;
}
