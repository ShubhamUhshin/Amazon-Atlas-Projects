package com.amazon.buspassmanagement.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.amazon.buspassmanagement.buspassSession;
import com.amazon.buspassmanagement.db.BusPassDAO;
import com.amazon.buspassmanagement.model.BusPass;

public class BusPassManagement {
	
	private BusPassManagement() {
	}
	
	// Create it as a Singleton 
	private static BusPassManagement manageBusPass = new BusPassManagement();
	Scanner scanner = new Scanner(System.in);
	BusPassDAO buspassDAO = new BusPassDAO();
	BusPass buspass = new BusPass();
	
	public static BusPassManagement getInstance() {
		return manageBusPass;
	}
	
	public void manageBusPass() {
		
		while(true) {
			System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
			System.out.println("1: View Bus Pass Requests");
			System.out.println("2: View Bus Pass Request By UserID");
			System.out.println("3: Update Bus Pass Request");
			System.out.println("4: Delete Bus Pass Request");
			System.out.println("5: Quit Managing BusPasses");
			System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
			System.out.println("Enter Your Choice: ");
			int choice = Integer.parseInt(scanner.nextLine());//scanner.nextInt();
			boolean quit = false;
			switch(choice) {
			case 1:
				viewPassRequests();
				break;
				
			case 2:
				System.out.println("Enter User ID: ");
				int userID = Integer.parseInt(scanner.nextLine());//scanner.nextInt();
				viewPassRequestsByUser(userID);
				break;
				
			case 3:
				approveRejectPassRequest();
				break;

			case 4:							
				deletePass();
				break;
				
			case 5:
				quit = true;
				break;
				
			default:
				System.err.println("Invalid Choice");
			}
			
			if(quit)
				break;
		} 	
	}

	public void viewPassRequests() {
	
	System.out.println("Enter Route ID to get All the Pass Reqeuests for a Route");
	System.out.println("Or 0 for All Bus Pass Requests");
	System.out.println("Enter Route ID: ");
	
	int routeID = Integer.parseInt(scanner.nextLine());//scanner.nextInt();
	
	List<BusPass> buspasses = null;
	
	if(routeID == 0) {
		buspasses = buspassDAO.retrieve();
	}else {
		String sql = "SELECT * from BusPass where routeID = "+routeID;
		buspasses = buspassDAO.retrieve(sql);
	}
	
	for(BusPass object : buspasses) {
		object.prettyPrint();
	}
}
	
	// Handler for the Bus Pass :)
	public void requestPass() {
		
		buspass.getDetails(false);
		
		// Add the User ID Implicitly.
		buspass.userID = buspassSession.user.id;
		
		// As initially record will be inserted by User where it is a request
		buspass.status = 1; // initial status as requested :)
		
		int result = buspassDAO.insert(buspass);
		String message = (result > 0) ? "Pass Requested Successfully" : "Request for Pass Failed. Try Again.."; 
		System.out.println(message);
	}
	
	public void deletePass() {
		
		System.out.println("Enter Pass ID to be deleted: ");
		buspass.buspassID = Integer.parseInt(scanner.nextLine());//scanner.nextInt();
		int result = buspassDAO.delete(buspass);
		String message = (result > 0) ? "Pass Deleted Successfully" : "Deleting Pass Failed. Try Again.."; 
		System.out.println(message);
	}
	
	/*
	 
	 	Extra Task:
	 	IFF : You wish to UpSkill :)
	 
	 	Scenario: Open the same application in 2 different terminals
	 	1 logged in by user
	 	another logged in by admin
	 	
	 	If admin, approves or rejects the pass -> User should be notified :)
	 	
	 	Reference Link
	 	https://github.com/ishantk/AmazonAtlas22/blob/master/Session8/src/com/amazon/atlas/casestudy/YoutubeApp.java
	 
	 */
	
	public void approveRejectPassRequest() {

		System.out.println("Enter Pass ID: ");
		buspass.buspassID = Integer.parseInt(scanner.nextLine());//scanner.nextInt();
		
		System.out.println("2: Approve");
		System.out.println("3: Cancel");
		System.out.println("Enter Approval Choice: ");
		buspass.status = Integer.parseInt(scanner.nextLine());//scanner.nextInt();

    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		
		Calendar calendar = Calendar.getInstance();
		Date date1 = calendar.getTime();
		buspass.approvedRejectedOn = dateFormat.format(date1);
		
		if(buspass.status == 2) {
			calendar.add(Calendar.YEAR, 1);
			Date date2 = calendar.getTime();
			buspass.validTill = dateFormat.format(date2);
		}else {
			buspass.validTill = buspass.approvedRejectedOn;
		}
		
		int result = buspassDAO.update(buspass);
		String message = (result > 0) ? "Pass Request Updated Successfully" : "Updating Pass Request Failed. Try Again.."; 
		System.out.println(message);
	}
	
	public void viewPassRequestsByUser(int userID) {
		
		String sql = "SELECT * from BusPass where userID = "+userID;
		List<BusPass> buspasses = buspassDAO.retrieve(sql);
		
		for(BusPass object : buspasses) {
			object.prettyPrint();
		}
	}
	
}
