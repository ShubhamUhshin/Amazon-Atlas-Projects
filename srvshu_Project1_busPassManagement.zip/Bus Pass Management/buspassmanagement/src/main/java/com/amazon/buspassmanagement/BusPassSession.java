package com.amazon.buspassmanagement;

import com.amazon.buspassmanagement.model.User;

public class BusPassSession {
	
	// This stores the user session
	// Initially the value is null
	public static User user = null;

}
