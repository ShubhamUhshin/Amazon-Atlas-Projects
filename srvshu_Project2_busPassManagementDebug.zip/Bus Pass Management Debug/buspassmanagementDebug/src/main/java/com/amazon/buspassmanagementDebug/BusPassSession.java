package com.amazon.buspassmanagementDebug;

import com.amazon.buspassmanagementDebug.model.User;

public class BusPassSession {

	// Can hold the reference of a User Object :)
	public static User user = null;
	
}
