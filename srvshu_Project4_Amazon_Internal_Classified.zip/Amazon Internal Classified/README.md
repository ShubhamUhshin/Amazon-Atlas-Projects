This is 3rd Atlas Project.

	Amazon Internal Classified App
		
		This project is like an OLX system for Users to Register, Log in, post classified for sale, buy classified.
		Classifieds include rental houses, phones etc.
		
		This project is build with Maven, contains SQL tables to store the data.
		
		MSSQL Tables-
		User Table is used to store the user data.
		Classified Table is used to store the Classified data.
		Order Table is used to store the classified transaction details.
		Category Table is used for storing the categories of classifieds available.
	
		